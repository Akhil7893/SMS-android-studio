package com.example.msgapp;

import android.content.Context;
import android.content.Intent;

public interface SmsReceiverr {
    void OnReceive(Context context, Intent intent);
}
